# Auto-Py-GPT

Auto-Py-GPT is a Python project that converts natural language instructions into PyAutoGUI scripts and executes them. This allows users to control their computer using simple, human-readable commands.

## Installation

1. Clone this repository:
   ```
   git clone https://github.com/yourusername/auto-py-gpt.git
   cd auto-py-gpt
   ```

2. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

3. Set up your API key in `config/config.yaml`.

## Usage

Run the script with a natural language instruction:
