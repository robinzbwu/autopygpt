import tempfile
import subprocess

class ScriptExecutor:
    def execute(self, script):
        with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as temp:
            temp.write(script)
            temp_name = temp.name

        try:
            subprocess.run(['python', temp_name], check=True)
        except subprocess.CalledProcessError as e:
            print(f"Error executing script: {e}")