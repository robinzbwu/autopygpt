import argparse
from .pyautogui_generator import PyAutoGUIGenerator
from .script_executor import ScriptExecutor

def main():
    parser = argparse.ArgumentParser(description="Convert natural language to PyAutoGUI scripts and execute them.")
    parser.add_argument("instruction", type=str, help="Natural language instruction to execute")
    args = parser.parse_args()

    pyautogui_generator = PyAutoGUIGenerator()
    script_executor = ScriptExecutor()

    script = pyautogui_generator.generate(args.instruction)
    print("Generated script:", script)
    script_executor.execute(script)

if __name__ == "__main__":
    main()