# Configuration settings

AZURE_API_KEY = "your-azure-api-key-here"
AZURE_ENDPOINT = "https://your-azure-endpoint.openai.azure.com/"
AZURE_DEPLOYMENT_NAME = "your-gpt-4-turbo-deployment-name"

class Config:
    def __init__(self):
        self.config = {
            "api_type": "azure",
            "api_key": AZURE_API_KEY,
            "api_base": AZURE_ENDPOINT,
            "api_version": "2023-05-15",  # Use the latest API version
            "deployment_name": AZURE_DEPLOYMENT_NAME
        }

    def get(self, key):
        return self.config.get(key)

def load_config():
    return Config()