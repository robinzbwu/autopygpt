import requests
from .config import load_config

config = load_config()
# Use config.get() to access configuration values

class NLPProcessor:
    def __init__(self):
        self.config = config
        self.api_key = self.config.get('api_key')
        self.api_url = self.config.get('api_url')

    def process(self, instruction):
        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        data = {
            "prompt": f"Convert the following instruction to a PyAutoGUI script: {instruction}",
            "max_tokens": 150
        }
        response = requests.post(self.api_url, headers=headers, json=data)
        return response.json()['choices'][0]['text'].strip()