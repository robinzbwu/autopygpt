from openai import AzureOpenAI
from .config import load_config

class PyAutoGUIGenerator:
    def __init__(self):
        config = load_config()
        self.client = AzureOpenAI(
            api_key=config.get("api_key"),
            api_version=config.get("api_version"),
            azure_endpoint=config.get("api_base")
        )
        self.deployment_name = config.get("deployment_name")

    def generate(self, instruction):
        prompt = f"Generate a PyAutoGUI script to perform the following action: {instruction}"
        
        response = self.client.chat.completions.create(
            model=self.deployment_name,
            messages=[
                {"role": "system", "content": "You are a helpful assistant that generates PyAutoGUI scripts."},
                {"role": "user", "content": prompt}
            ],
            temperature=0.7,
            max_tokens=300
        )
        
        return response.choices[0].message.content.strip()

# ... existing code ...